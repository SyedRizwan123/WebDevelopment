//console.log("Hello world");

/*let message;
message ="Hello Syed";
console.log(message);*/

/*let message;
console.log(message);*/

//Operator
/*let x=10;
let y=20;
console.log(x+y);
console.log(y-x);
console.log(y/x);
console.log(x*y);*/

/*let x=10;
let y=5.7;
console.log(typeof(x));
console.log(typeof(y));*/

/*let isApproved=true;
console.log(typeof(isApproved));*/

/*let greet ='Hello Good Morning';
let greet1="Hello Good afternoon";
let greet3=`Hello Good Evening`;

console.log(greet);
console.log(greet1);
console.log(greet3);*/

//Logical Operators
/*console.log(1 && 1);    //And Operator
console.log(0 || 1);   //OR Operator
console.log("---------------------------------------------");*/

//Comparasion Operators
/*console.log(10==10);   //true
console.log(10==0);    //false
console.log(10!=0);    //
console.log(10>9);
console.log(10<9);
console.log(10<10);
console.log(10<=10);
console.log("---------------------------------------");*/

/*let x = 10;
let y = 20;

if(x>y)
{
    console.log("true");
    a=10;
    b=20;
    console.log(b-a);
}
else{
    console.log("false");
}*/

//Nested if: Specifying a if statement within another if statement
/*a = 10;
b = 20;
c = 30;
if(a>b)       //Condition1
{
    if(b>c)   //condition 2
    {
        console.log("true");
    }
    else
    {
        console.log("false");
    }
}
else{
    console.log("1st condition is false");

}
console.log("-------------------------------------------------------");*/

//else if: Else if statements in JS is  like another condition, it is used In a program when if statement having multiple decisions.
let maths = 79;
let science = 87;
let social = 80;

Total = 79+87+80;
console.log("Total:" + Total);

Avg = Total/3;
console.log("Avg:"+ Avg);

if(Avg >= 85) //condition 1
{
    console.log("A Grade");
}
else if(Avg >= 65)   //condtion 2
    {
    console.log("B Grade");
}
else if(Avg>=50)
    {
    console.log("C Grade");
}
else{
    console.log("D Grade");
}
console.log("----------------------------------------");




