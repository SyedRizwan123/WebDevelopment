//loop: The process of repeatedly executing a collection of statements called Looping. (or)
// A loop statement allows us to execute a statement or group of statements multiple times.

//forloop: Executes a sequence of statements multiple times and abbreviates the code that manages the loop variable
/*for(let i=0; i<=10; i++)
    {
        console.log(i);
    
    }
console.log("-----------------------------------------");*/


//while loop: Repeats a statement or group of statements while a given condition is
//TRUE. It tests the condition before executing the loop body.
/*i =0;
while(i<=10)
{
    console.log(i);
    i++
}

console.log("--------------------------------------------")*/

//Arrays: An array is a special variable, which can hold more than one value
/*let my_Array = [25,"Syed",4.5,'M'];
console.log(my_Array);
console.log(my_Array[0]);
console.log(my_Array[1]);
console.log(my_Array[2]);
console.log(my_Array[3]);

//update the element
my_Array[0] = 26;
console.log("Updated Array:"+ my_Array);
console.log(my_Array[0]);
console.log("------------------------------------------------");*/

//finding Array length
/*let my_Array = [25,"Syed",4.5,'M'];
console.log(my_Array.length);
console.log("-------------------------------------------------");*/

//Array Methods:
//push(): The push() method adds new items to the end of the array. it will add last in elements
/*let myArray1=[5,"Syed",6.2];
console.log(myArray1)
myArray1.push(true);
console.log("After Push:"+ myArray1);*/

//pop Method: The pop() method removes the last item of an array, and returns that item,
/*let myArray2=[5,"hello",8.2,65,"help"];
let lastitem= myArray2.pop();
console.log("before use pop", myArray2);
console.log("after use pop", lastitem);*/

// Arrays with loop
/*let array_data = [1, 2, 3, "Name", "Village", 42.5];
console.log("--Printing/Accessing Array elements---");
for (let i = 0; i < array_data.length; i++) {
    console.log(`array_data[${i}]: ${array_data[i]}`);
}*/

//functions
/*function greet() 
{
    console.log("Hello Good mrngg Syed");
}   
greet()*/

//passing the parameters
/*function greet1(name){
    console.log('Good Morning'+ name);
    
}
greet1(" Syed");*/

//Passing multiple parameters
/*function about_me(name,age,designation)
{
    console.log('My name is' +name + ' im '+age +' years old'+ ' and my designation is ' + designation);
}
about_me(' Syed',  26, " Software Developer");*/

//Arrow function
/*const greet2 = (name) => {
    console.log('Good Morning' + name);
}

greet2(" Rizwan");*/

//function expression
/*const multiply = function(a,b){
    return a*b;
}
let result1 = multiply(2,3);
console.log(result1);*/

/*const square = (x) => x*x;
let result2 = square(2);
console.log(result2);*/

//Function Scope:Variables declared inside a function are scoped to that function and not accessible from outside
/*function myFunction() {
    let carName = "Volvo";  
    console.log(carName);
}*/
//myFunction();
//console.log(carName); // This will raise an error because carName is not defined outside the function

//Global Scope: A variable declared outside a function, becomes global and can be accessed from anywhere in the program
/*let carName = "Volvo";  // Global scope
function myFunction() {
    console.log(carName); // Accessible here
}
myFunction();
console.log(carName);*/ // Accessible here too


/*function outer() 
{
    let message = 'Hello';
  
    function inner() {
      console.log(message);
    }
  
    return inner;
  }
  
  let closure = outer();
  closure(); // Output: Hello*/

//Callbacks: Functions can be passed as arguments to other functions, commonly used in asynchronous operations.
/*function fetchData(callback) 
{
    // Simulate an asynchronous operation
    setTimeout(function() 
    {
      let data = 'This is the data';
      callback(data);
    }, 1000);
  }
  
  function displayData(data) {
    console.log(data);
  }
  
  fetchData(displayData); // Output: This is the data (after a 2-second delay)*/  

//Named and Anonymous Functions: Functions can be named or anonymous. Named functions have a name, and anonymous functions do not.

// Named function
/*function namedFunction() 
{
    console.log('I am named');
}  
namedFunction();*/

// Anonymous function assigned to a variable
/*const anonymousFunction = function() {
    console.log('I am anonymous');
  };
anonymousFunction();*/

//hoisted function:
/*hoistedFunction(); // This works because of hoisting
function hoistedFunction() {
  console.log('I am hoisted');
}*/

