function switchOff()
{
    document.getElementById("bulbimage").src="https://res.cloudinary.com/dom1itlkl/image/upload/v1768970520/ChatGPT_Image_Jan_21__2026__09_46_55_AM-removebg-preview_v5fgym.png";
    document.getElementById("catimage").src="https://res.cloudinary.com/dom1itlkl/image/upload/v1768970395/ChatGPT_Image_Jan_21__2026__10_07_50_AM-removebg-preview_av3lqb.png";
    document.getElementById("switchStatus").textContent="SwitchedOff";
    document.getElementById("onSwitch").style.backgroundColor="#22c55e";
    document.getElementById("offSwitch").style.backgroundColor="#f20202";

}

function switchOn()
{
    document.getElementById("bulbimage").src="https://res.cloudinary.com/dom1itlkl/image/upload/v1768970395/ChatGPT_Image_Jan_21__2026__09_47_49_AM-removebg-preview_rgslch.png";
    document.getElementById("catimage").src="https://res.cloudinary.com/dom1itlkl/image/upload/v1768970396/ChatGPT_Image_Jan_21__2026__10_05_01_AM-removebg-preview_tll6md.png";
    document.getElementById("switchStatus").textContent="SwitchedOn"
}
