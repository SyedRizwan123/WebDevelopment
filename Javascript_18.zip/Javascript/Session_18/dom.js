function manipulateStyle()
{
    document.getElementById("headingelement").textContent="4.0 Technologies";
    document.getElementById("headingelement").style.color="blue";
}